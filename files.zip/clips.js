// ClipForge "brain": sends a transcript to Claude and returns the best clips.
// The API key is read from Vercel's secret settings (ANTHROPIC_API_KEY). Never type it in this file.

const MODEL = "claude-sonnet-5-5"; // if Anthropic changes the name, edit only this line

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ error: "ANTHROPIC_API_KEY is missing in Vercel settings" });

  const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
  const transcript = String(body.transcript || "").slice(0, 60000);
  const streamer = String(body.streamer || "the streamer").slice(0, 40);
  const niche = String(body.niche || "general").slice(0, 40);
  if (transcript.length < 200) return res.status(400).json({ error: "Transcript is too short (need at least 200 characters)" });

  const prompt = `You are an expert short-form video editor for YouTube Shorts.
Below is a transcript of a ${niche} stream by ${streamer}. Lines may start with a timestamp like [00:12:30] or [750].
Pick the 3 to 5 moments most likely to go viral as 20-60 second vertical clips (strong hook, emotion, surprise, humor, or a clear payoff).
Return ONLY a JSON array, no other text. Each item must be:
{"start": seconds, "end": seconds, "title": "max 70 chars, curiosity-driven", "hook": "first caption line, max 12 words",
 "description": "2-3 sentences for the YouTube description, ends with a call to subscribe",
 "hashtags": ["#Shorts", "...", up to 8 total], "score": 1-100}
Use only timestamps that exist in the transcript. Do not invent events.

TRANSCRIPT:
${transcript}`;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: 2000, messages: [{ role: "user", content: prompt }] }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(502).json({ error: (data.error && data.error.message) || "Claude API error" });
    const text = (data.content || []).map((b) => b.text || "").join("");
    const clips = JSON.parse(text.replace(/```json|```/g, "").trim());
    return res.status(200).json({ clips });
  } catch (e) {
    return res.status(500).json({ error: "Could not read Claude's answer: " + e.message });
  }
};
